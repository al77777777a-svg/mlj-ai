// PCM helpers. Discord voice decodes to 48 kHz, 16-bit, stereo PCM;
// speech-to-text services prefer 16 kHz mono WAV (and it uploads 6x smaller).

export const DISCORD_RATE = 48000;
export const DISCORD_CHANNELS = 2;

/** Length in milliseconds of a 16-bit PCM buffer. */
export function pcmDurationMs(byteLength, rate = DISCORD_RATE, channels = DISCORD_CHANNELS) {
  return (byteLength / (rate * channels * 2)) * 1000;
}

/** Root-mean-square level (0 … 32768) of 16-bit PCM — a rough loudness measure. */
export function rms(pcm) {
  const samples = Math.floor(pcm.length / 2);
  if (!samples) return 0;
  let sum = 0;
  for (let i = 0; i < samples; i++) {
    const s = pcm.readInt16LE(i * 2);
    sum += s * s;
  }
  return Math.sqrt(sum / samples);
}

/** 48 kHz stereo → 16 kHz mono: average both channels and every 3 frames. */
export function stereo48kToMono16k(pcm) {
  const frames = Math.floor(pcm.length / 4);
  const outFrames = Math.floor(frames / 3);
  const out = Buffer.alloc(outFrames * 2);
  for (let o = 0; o < outFrames; o++) {
    let acc = 0;
    for (let k = 0; k < 3; k++) {
      const i = (o * 3 + k) * 4;
      acc += pcm.readInt16LE(i) + pcm.readInt16LE(i + 2);
    }
    out.writeInt16LE(Math.round(acc / 6), o * 2);
  }
  return out;
}

/** Wrap raw 16-bit PCM in a WAV header. */
export function pcmToWav(pcm, rate, channels) {
  const header = Buffer.alloc(44);
  header.write('RIFF', 0, 'ascii');
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write('WAVE', 8, 'ascii');
  header.write('fmt ', 12, 'ascii');
  header.writeUInt32LE(16, 16); // fmt chunk size
  header.writeUInt16LE(1, 20); // PCM
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(rate, 24);
  header.writeUInt32LE(rate * channels * 2, 28); // byte rate
  header.writeUInt16LE(channels * 2, 32); // block align
  header.writeUInt16LE(16, 34); // bits per sample
  header.write('data', 36, 'ascii');
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

// Speech-to-text through an OpenAI-compatible /audio/transcriptions endpoint
// (Groq Whisper by default, or OpenAI).
import { config } from './config.js';

function buildForm(audio, file, withHints) {
  const { model } = config.stt;
  const language = config.stt.language.toLowerCase() === 'auto' ? '' : config.stt.language;
  const form = new FormData();
  form.append('file', new Blob([audio], { type: file.type }), file.name);
  form.append('model', model);
  form.append('response_format', 'json');
  if (!withHints) return form;

  // Hints help the model spell the bot's name and expect Arabic.
  const names = [...new Set([config.botName, ...config.wakeWords])];
  if (model.startsWith('gpt-transcribe')) {
    for (const name of names) form.append('keywords[]', name);
    for (const lang of new Set([language || 'ar', 'en'])) form.append('languages[]', lang);
  } else {
    if (language) form.append('language', language);
    form.append('prompt', `${names.join('، ')}.`);
  }
  return form;
}

async function post(form) {
  return fetch(config.stt.url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${config.stt.apiKey}` },
    body: form,
    signal: AbortSignal.timeout(30_000),
  });
}

/**
 * Sends audio (a WAV buffer by default) and returns the transcript
 * ('' if nothing was understood).
 */
export async function transcribe(audio, file = { name: 'speech.wav', type: 'audio/wav' }) {
  let res = await post(buildForm(audio, file, true));
  // If the service rejects an optional hint, try once more without hints.
  if (res.status === 400) res = await post(buildForm(audio, file, false));
  if (!res.ok) {
    const detail = (await res.text().catch(() => '')).slice(0, 300);
    throw new Error(`STT ${res.status}: ${detail}`);
  }
  const data = await res.json();
  return String(data?.text ?? '').trim();
}

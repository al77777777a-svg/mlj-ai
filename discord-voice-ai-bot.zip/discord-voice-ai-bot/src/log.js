import { config } from './config.js';

let clock;
try {
  clock = new Intl.DateTimeFormat('en-GB', { timeStyle: 'medium', hour12: false, timeZone: config.timezone });
} catch {
  clock = new Intl.DateTimeFormat('en-GB', { timeStyle: 'medium', hour12: false });
}
const time = () => clock.format(new Date());

export const log = {
  info: (...args) => console.log(`[${time()}]`, ...args),
  warn: (...args) => console.warn(`[${time()}] ⚠️`, ...args),
  error: (...args) => console.error(`[${time()}] ❌`, ...args),
  debug: (...args) => {
    if (config.debug) console.log(`[${time()}] 🐞`, ...args);
  },
};

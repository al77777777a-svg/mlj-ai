import { SlashCommandBuilder } from 'discord.js';

export const commands = [
  new SlashCommandBuilder().setName('join').setDescription('البوت يدش الروم الصوتي اللي أنت فيه ويسمعكم'),

  new SlashCommandBuilder().setName('leave').setDescription('البوت يطلع من الروم'),

  new SlashCommandBuilder()
    .setName('ask')
    .setDescription('اسأل البوت كتابة ويرد عليك (وبصوت إذا هو في الروم)')
    .addStringOption((option) =>
      option.setName('question').setDescription('سؤالك').setRequired(true).setMaxLength(1000),
    ),

  new SlashCommandBuilder()
    .setName('mode')
    .setDescription('متى يرد البوت؟')
    .addStringOption((option) =>
      option
        .setName('when')
        .setDescription('اختر طريقة الرد')
        .setRequired(true)
        .addChoices(
          { name: 'بس لما أناديه باسمه', value: 'name' },
          { name: 'على أي كلام في الروم', value: 'everyone' },
        ),
    ),

  new SlashCommandBuilder().setName('stop').setDescription('يسكت البوت ويلغي الردود اللي بالانتظار'),

  new SlashCommandBuilder().setName('reset').setDescription('البوت ينسى السالفة ويبدأ من جديد'),
].map((command) => command.toJSON());

// Text-to-speech. Returns an audio file (WAV or MP3) as a Buffer;
// ffmpeg converts it for Discord when it is played.
import { config } from './config.js';
import { mostlyLatin } from './text.js';

/** Longest piece of text sent in one request (Groq's Arabic voice allows 200). */
export function ttsChunkLimit() {
  return config.tts.provider === 'groq' ? 190 : 400;
}

export async function synthesize(text) {
  const english = mostlyLatin(text);
  switch (config.tts.provider) {
    case 'groq':
      return groqSpeech(text, english);
    case 'azure':
      return azureSpeech(text, english);
    case 'elevenlabs':
      return elevenLabsSpeech(text);
    default:
      throw new Error(`Unknown TTS_PROVIDER "${config.tts.provider}"`);
  }
}

// Groq (Canopy Labs Orpheus): Saudi-dialect Arabic voices + English voices.
function groqSpeech(text, english) {
  const g = config.tts.groq;
  return fetchAudio('https://api.groq.com/openai/v1/audio/speech', {
    headers: { Authorization: `Bearer ${g.apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: english ? g.modelEn : g.modelAr,
      voice: english ? g.voiceEn : g.voiceAr,
      input: text,
      response_format: 'wav',
    }),
  });
}

// Azure AI Speech: Emirati voices (ar-AE-HamdanNeural / ar-AE-FatimaNeural).
function azureSpeech(text, english) {
  const a = config.tts.azure;
  const voice = english ? a.voiceEn : a.voiceAr;
  const lang = voice.split('-').slice(0, 2).join('-');
  const ssml =
    `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${lang}">` +
    `<voice name="${escapeXml(voice)}">${escapeXml(text)}</voice></speak>`;
  return fetchAudio(`https://${a.region}.tts.speech.microsoft.com/cognitiveservices/v1`, {
    headers: {
      'Ocp-Apim-Subscription-Key': a.apiKey,
      'Content-Type': 'application/ssml+xml',
      'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3',
      'User-Agent': 'discord-voice-ai-bot',
    },
    body: ssml,
  });
}

// ElevenLabs: very natural multilingual voices (pick an Arabic voice ID).
function elevenLabsSpeech(text) {
  const e = config.tts.elevenlabs;
  const url = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(e.voiceId)}?output_format=mp3_44100_128`;
  return fetchAudio(url, {
    headers: { 'xi-api-key': e.apiKey, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
    body: JSON.stringify({ text, model_id: e.model }),
  });
}

async function fetchAudio(url, { headers, body }) {
  const res = await fetch(url, { method: 'POST', headers, body, signal: AbortSignal.timeout(30_000) });
  if (!res.ok) {
    const detail = (await res.text().catch(() => '')).slice(0, 300);
    throw new Error(`TTS ${res.status}: ${detail}`);
  }
  return Buffer.from(await res.arrayBuffer());
}

function escapeXml(value) {
  return String(value).replace(
    /[<>&'"]/g,
    (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' })[c],
  );
}

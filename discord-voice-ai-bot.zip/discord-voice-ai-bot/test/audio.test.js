import { test } from 'node:test';
import assert from 'node:assert/strict';
import { pcmDurationMs, pcmToWav, rms, stereo48kToMono16k } from '../src/audio.js';

// 48 kHz stereo sine wave, 16-bit little-endian.
function sine({ seconds, freq = 440, amplitude = 8000 }) {
  const frames = Math.round(48000 * seconds);
  const buf = Buffer.alloc(frames * 4);
  for (let i = 0; i < frames; i++) {
    const v = Math.round(amplitude * Math.sin((2 * Math.PI * freq * i) / 48000));
    buf.writeInt16LE(v, i * 4);
    buf.writeInt16LE(v, i * 4 + 2);
  }
  return buf;
}

test('duration of 48 kHz stereo PCM', () => {
  assert.equal(pcmDurationMs(sine({ seconds: 1 }).length), 1000);
  assert.equal(pcmDurationMs(3840), 20); // one Discord opus frame
});

test('rms of silence and of a sine wave', () => {
  assert.equal(rms(Buffer.alloc(4800)), 0);
  const level = rms(sine({ seconds: 0.5, amplitude: 8000 }));
  assert.ok(Math.abs(level - 8000 / Math.SQRT2) < 50, String(level));
});

test('48 kHz stereo → 16 kHz mono keeps length and loudness', () => {
  const input = sine({ seconds: 1, freq: 300, amplitude: 10000 });
  const out = stereo48kToMono16k(input);
  assert.equal(out.length, 16000 * 2);
  assert.ok(Math.abs(rms(out) - rms(input)) / rms(input) < 0.05);
});

test('WAV header is valid', () => {
  const pcm = Buffer.alloc(3200);
  const wav = pcmToWav(pcm, 16000, 1);
  assert.equal(wav.length, 44 + 3200);
  assert.equal(wav.toString('ascii', 0, 4), 'RIFF');
  assert.equal(wav.readUInt32LE(4), 36 + 3200);
  assert.equal(wav.toString('ascii', 8, 16), 'WAVEfmt ');
  assert.equal(wav.readUInt16LE(20), 1);
  assert.equal(wav.readUInt16LE(22), 1);
  assert.equal(wav.readUInt32LE(24), 16000);
  assert.equal(wav.readUInt32LE(28), 32000);
  assert.equal(wav.readUInt16LE(34), 16);
  assert.equal(wav.toString('ascii', 36, 40), 'data');
  assert.equal(wav.readUInt32LE(40), 3200);
});

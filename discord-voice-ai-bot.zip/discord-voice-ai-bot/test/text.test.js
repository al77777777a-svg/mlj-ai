import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  cleanForSpeech,
  containsWakeWord,
  fillTemplate,
  isOnlyWakeWord,
  isStopCommand,
  looksLikeNoise,
  mostlyLatin,
  normalize,
  splitForSpeech,
} from '../src/text.js';

const WAKE = ['كلود', 'كلاود', 'claude', 'بوت'];
const STOP = ['اسكت', 'خلاص', 'بس', 'وقف', 'كفايه', 'stop'];

test('normalize unifies Arabic letter forms and drops diacritics', () => {
  assert.equal(normalize('إِنْ شَاءَ اللّٰهُ'), normalize('ان شاء الله'));
  assert.equal(normalize('كفاية!'), 'كفايه');
  assert.equal(normalize('  Hey, CLAUDE...  '), 'hey claude');
});

test('wake word is found with or without attached particles', () => {
  assert.ok(containsWakeWord('يا كلود شو الجو اليوم؟', WAKE));
  assert.ok(containsWakeWord('ياكلود شو الجو', WAKE));
  assert.ok(containsWakeWord('البوت شو رايك', WAKE));
  assert.ok(containsWakeWord('Hey Claude, what time is it?', WAKE));
  assert.ok(containsWakeWord('كلاود تعال', WAKE));
});

test('wake word does not match inside other words', () => {
  assert.ok(!containsWakeWord('رحت البوتيك امس', WAKE));
  assert.ok(!containsWakeWord('the cloudy sky', WAKE));
  assert.ok(!containsWakeWord('شو تسوون اليوم', WAKE));
  assert.ok(!containsWakeWord('رايح السوق', ['راي']));
  assert.ok(containsWakeWord('يا راي وين', ['راي']));
});

test('multi-word wake words', () => {
  assert.ok(containsWakeWord('يا بوت قول نكته', ['يا بوت']));
  assert.ok(!containsWakeWord('بوت', ['يا بوت']));
});

test('only calling the name', () => {
  assert.ok(isOnlyWakeWord('يا كلود', WAKE));
  assert.ok(isOnlyWakeWord('كلود؟', WAKE));
  assert.ok(isOnlyWakeWord('Hey Claude', WAKE));
  assert.ok(!isOnlyWakeWord('يا كلود كم الساعة', WAKE));
  assert.ok(!isOnlyWakeWord('مرحبا', WAKE));
});

test('stop commands', () => {
  assert.ok(isStopCommand('اسكت', STOP, WAKE));
  assert.ok(isStopCommand('خلاص خلاص', STOP, WAKE));
  assert.ok(isStopCommand('كلود وقف', STOP, WAKE));
  assert.ok(isStopCommand('يا كلود كفاية', STOP, WAKE));
  assert.ok(isStopCommand('Stop!', STOP, WAKE));
  assert.ok(!isStopCommand('بس شو رايك في الموضوع', STOP, WAKE));
  assert.ok(!isStopCommand('يا كلود', STOP, WAKE));
  assert.ok(!isStopCommand('', STOP, WAKE));
});

test('speech-to-text hallucinations are filtered', () => {
  assert.ok(looksLikeNoise('ترجمة نانسي قنقر'));
  assert.ok(looksLikeNoise('اشتركوا في القناة'));
  assert.ok(looksLikeNoise('Thank you.'));
  assert.ok(looksLikeNoise('...'));
  assert.ok(looksLikeNoise(''));
  assert.ok(!looksLikeNoise('يا كلود شو الجو'));
  assert.ok(!looksLikeNoise('هلا'));
});

test('cleanForSpeech removes markdown, links and emoji', () => {
  const raw = '**هلا** 👋\n- أول شي\n- ثاني شي\nشوف https://example.com/page';
  const clean = cleanForSpeech(raw);
  assert.ok(!/[*👋]|https?:/u.test(clean), clean);
  assert.ok(clean.includes('هلا'));
  assert.ok(clean.includes('أول شي'));
  assert.ok(!clean.includes('- '));
});

test('splitForSpeech keeps every piece under the limit and loses no words', () => {
  const sentence = 'هذي جملة طويلة شوي عشان نجرب التقسيم، وفيها فواصل كثيرة، وكلام زايد';
  const text = Array.from({ length: 8 }, (_, i) => `${sentence} رقم ${i}.`).join(' ');
  for (const max of [60, 120, 190]) {
    const pieces = splitForSpeech(text, max);
    assert.ok(pieces.length > 1);
    for (const p of pieces) assert.ok(p.length <= max, `${p.length} > ${max}: ${p}`);
    assert.equal(normalize(pieces.join(' ')), normalize(text));
  }
});

test('splitForSpeech handles a single long word and short text', () => {
  const long = 'ا'.repeat(450);
  const pieces = splitForSpeech(long, 190);
  assert.ok(pieces.every((p) => p.length <= 190));
  assert.equal(pieces.join(''), long);
  assert.deepEqual(splitForSpeech('هلا والله', 190), ['هلا والله']);
  assert.deepEqual(splitForSpeech('', 190), []);
});

test('mostlyLatin picks the right voice language', () => {
  assert.ok(mostlyLatin('Hello there, how are you?'));
  assert.ok(!mostlyLatin('هلا والله، شخبارك؟'));
  assert.ok(!mostlyLatin('هلا Claude شخبارك اليوم'));
});

test('fillTemplate replaces known placeholders only', () => {
  assert.equal(fillTemplate('أنا {{BOT_NAME}} في {{ SERVER_NAME }} {{X}}', { BOT_NAME: 'كلود', SERVER_NAME: 'السيرفر' }),
    'أنا كلود في السيرفر {{X}}');
});
